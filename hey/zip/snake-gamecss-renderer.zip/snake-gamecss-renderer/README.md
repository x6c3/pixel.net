# Snake Game - CSS Renderer

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackrugile/pen/bGRWbK](https://codepen.io/jackrugile/pen/bGRWbK).

This is a basic snake game made with JavaScript for logic and CSS for rendering. Use the arrow keys or WASD to control the snake. You can loop through walls.

Good luck! Post your high score in the comments.